import java.util.InputMismatchException;
import java.util.Scanner;
/**
 * @author Pal Patel
 * @version 1.0
 * Class for computing the results of input values passed to a Beta function.
 */
public class Beta {
	  /**
	   * Main method taking the input values x and y and making necessary calls to compute B(x,y).
	   */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter input x");
		String stringx= in.nextLine();
		double x = Double.parseDouble(stringx);
		System.out.println("Enter input y");
		String stringy= in.nextLine();
		double y = Double.parseDouble(stringy);	
		double beta = (gamma(x) * gamma(y))/gamma(x+y);		
		System.out.println("The result of the beta function with inputs x= " + x + " and y= " + y + " is " +beta);
		}
		catch(InputMismatchException e){
			System.out.println("Invalid input. Please enter a positive real number");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
		
	  /**
	   * Computes the gamma value of the passed parameter
	   * @param temp The input to the gamma function
	   * @return Gamma computation result
	   */
	public static double gamma(double temp) throws Exception {

		// TODO Auto-generated method stub
		double pi=3.141592653589793238;
		double e= 2.718281828459045235;
		if(!(temp>0)){
			throw new Exception("Invalid Inputs Exception. Please enter real and positive inputs for the beta function");
		}	
		else if(temp%1==0) {
			 return factorial(temp-1);
		}
		else {
		temp=temp-1;
		double sqroot = sq(2*pi*temp);
		double base=(temp/e);
		double pow = calculatepower(base, temp);
		return ((sqroot) *(pow));	
		}
	}
	  /**
	   * Computes the square root
	   * @param number 
	   * @return root
	   */
	public static double sq(double number) {
		if(number<=0) {
			return 0;
		}
		double root = number / 2;		
		double t = root;
		root = (t + (number / t)) / 2;
	 
		while ((t - root) != 0){
			t = root;
			root = (t + (number / t)) / 2;
		} 	 
		return root;
	}
	
	  /**
	   * Computes the power
	   * @param a,b Base and Exponent
	   * @return pwr
	   */
	static double calculatepower(double a,double b)
	{
		double pwr=1;
		int i=1;
		while(i<=b)	
		{
			pwr=pwr*a;
			i++;
		}
		return pwr;
	}
	  /**
	   * Computes the factorial
	   * @param num The number whose factorial is to be calculated
	   * @return factorial result
	   */
	static double factorial(double num)
	{
		if(num<=1)
			return 1;
		else 
			return (num*factorial(num-1));		
	}
}