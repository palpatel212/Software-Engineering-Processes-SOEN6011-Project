import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author Pal Patel
 * @version 1.0
 * JUnit TestCase Class for Beta function's sub calculations
 */
public class TestCasesBeta {
	
	@Test
	/**
	 * Testing the gamma function
	 */
	void testgamma() throws Exception {
		assertEquals(6, Beta.gamma(4.0));
	}
	
	@Test
	/**
	 * Testing the square root function
	 */
	void testsq() {
		assertEquals(17, Beta.sq(289));
	}
	
	@Test
	/**
	 * Testing the power function
	 */
	void testcalculatepower() {
		assertEquals(8, Beta.calculatepower(2,3));
	}

	/**
	 * Testing the factorial function
	 */
	@Test
	void testfactorial() {
		assertEquals(120, Beta.factorial(5.0));
	}
	
	/**
	 * Testing the exception
	 */
	@Test
	void testexception() {
		Exception obj= assertThrows(Exception.class, () -> {Beta.gamma(-1.5);});
		String expected= "Invalid Inputs Exception. Please enter real and positive inputs for the beta function";
		String actual = obj.getMessage();
		assertTrue(actual.contains(expected));
	}

}
